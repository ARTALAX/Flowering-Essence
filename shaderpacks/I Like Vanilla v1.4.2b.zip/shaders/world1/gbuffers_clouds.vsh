#version 140

#define SHADER_GBUFFERS_CLOUDS
#define END
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/gbuffers_clouds.glsl"
